﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading.Tasks;

namespace BacaSensor
{
    public partial class Form1 : Form
    {
        string stringRx;
        public Form1()
        {
            InitializeComponent();
            string[] ports = SerialPort.GetPortNames();
            foreach (string port in ports)
            {
                comboBox1.Items.Add(port);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void connectButton_Click(object sender, EventArgs e)
        {
            serialPort1.PortName = comboBox1.Text;
            serialPort1.BaudRate = 9600;
            serialPort1.Open();
            connectButton.Enabled = false;
            disconnectButton.Enabled = true;

        }

        private void disconnectButton_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
            connectButton.Enabled = true;
            disconnectButton.Enabled = false;
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            stringRx = serialPort1.ReadLine();
            this.Invoke(new EventHandler(displayText));
            
        }

        private void displayText(object sender, EventArgs e)
        {
            textBox1.AppendText(stringRx + " " + "\n");
            textBox2.AppendText(stringRx.Substring(4, 2) + "\n");
            textBox3.AppendText(stringRx.Substring(12, 2) + "\n");
            textBox4.AppendText(stringRx.Substring(14, 2) + "\n");
            textBox5.AppendText(stringRx.Substring(23, 5) + "\n");
            
            
        }

        
       

        
    }
}
